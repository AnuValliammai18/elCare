package com.example.elcare.model

data class HealthRecord(
    var bp: Int = 0,
    var glucose: Int = 0,
    var heartRate: Int = 0
)